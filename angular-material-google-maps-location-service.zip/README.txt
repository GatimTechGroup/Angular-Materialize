A Pen created at CodePen.io. You can find this one at http://codepen.io/batressc/pen/QjEGXY.

 Ejemplo de cómo utilizar GoogleMaps v3 API & Location service con Angular.js, Angular-Material y Lodash

Ver en linea:
http://ba3-angularmaterial-googlemaps-location.azurewebsites.net/app/