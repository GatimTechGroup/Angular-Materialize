A Pen created at CodePen.io. You can find this one at http://codepen.io/AntoniGorski/pen/doNgZZ.

 Responsive gallery with dynamically loaded images. It uses AngularJS's implementation of Google's Material Design and Masonry as gallery framework.