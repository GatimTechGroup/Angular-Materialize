A Pen created at CodePen.io. You can find this one at http://codepen.io/cln/pen/Jdamzj.

 Todo list using Angular, Angular Material, Angular/HTML5 drag-and-drop reordering and persistent local storage.