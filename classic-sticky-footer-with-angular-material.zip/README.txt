A Pen created at CodePen.io. You can find this one at http://codepen.io/rscafi/pen/bNXRxY.

 http://stackoverflow.com/questions/27090257/how-to-implement-the-classic-sticky-footer-with-angular-material