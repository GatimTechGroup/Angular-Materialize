A Pen created at CodePen.io. You can find this one at http://codepen.io/boo0330/pen/gpQVKB.

 Angular Material Design Header, Ripple Button, and Toggled Sidebar