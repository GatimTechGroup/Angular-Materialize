A Pen created at CodePen.io. You can find this one at http://codepen.io/nanarth/pen/qEEpZV.

 I took example from https://material.angularjs.org/#/demo/material.components.button and tried to make it work.

Next step will be to use a real cdn and experience more.