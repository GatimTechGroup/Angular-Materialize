A Pen created at CodePen.io. You can find this one at http://codepen.io/ChrisHuie/pen/XbrZbd.

 Input with autocomplete of NBA playoff teams using angular material. Love the floating labels and the built in styles.