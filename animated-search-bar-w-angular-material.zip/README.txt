A Pen created at CodePen.io. You can find this one at http://codepen.io/declanelcocks/pen/GpRMPo.

 I've taken inspiration from @pixelass to create my own morphing search icon. I also added a little JavaScript to remove the header and make sure the search bar fills the entire navbar.