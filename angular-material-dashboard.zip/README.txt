A Pen created at CodePen.io. You can find this one at http://codepen.io/ajatix/pen/vNpwYB.

 This is a basic application template for AngularJS using the Angular Material library