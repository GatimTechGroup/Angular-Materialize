A Pen created at CodePen.io. You can find this one at http://codepen.io/batressc/pen/mJYEvZ.

 Utilización de angular-material y lodash para hacer un mantenimiento simple para un array de elementos. Ver el demo online en:

http://ba3-simplecrud-array.azurewebsites.net/app/index.html

Directivas y componentes utilizados:
md-button, md-list, md-content, $mdDialog, $mdToast, $mdIcon, md-toolbar, md-tooltip, md-menu