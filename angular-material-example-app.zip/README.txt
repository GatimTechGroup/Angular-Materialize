A Pen created at CodePen.io. You can find this one at http://codepen.io/njmcode/pen/doEjZe.

 A dummy AdWords campaign setup type thing using Angular and the angular-material add-on