A Pen created at CodePen.io. You can find this one at http://codepen.io/jernejcic/pen/LGpNYg.

 Create a scrollable div. The intent here is to be able to create a view that does not expand it's height and force the browser to scroll, thereby scrolling other content off of the screen. Instead, the div itself is scrollable and does not affect other content in view.