A Pen created at CodePen.io. You can find this one at http://codepen.io/kyleledbetter/pen/BjaeYJ.

 Building out an angular-material layout inspired by this Polymer layout polymerelements.github.io/app-layout-templates/nav-list-detail/index.html with a navigation drawer (sidenav), list and content area, all responsive