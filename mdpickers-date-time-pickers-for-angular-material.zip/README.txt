A Pen created at CodePen.io. You can find this one at http://codepen.io/alenaksu/pen/eNzbrZ.

 Material Design date/time pickers built with Angular Material and Moment.js. 
Clone it on [github](https://github.com/alenaksu/mdPickers)

